import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import ScrollReveal from "./ScrollReveal";

const faqs = [
  { q: "Does teeth whitening hurt?", a: "Our professional whitening treatment is designed for comfort. Most patients experience little to no sensitivity, and we use desensitizing agents to ensure a gentle experience." },
  { q: "How much do dental implants cost?", a: "Implant costs vary based on the complexity of your case. During your consultation, we provide a detailed, transparent cost breakdown with no hidden fees. We also offer flexible payment plans." },
  { q: "Can I book a same-day appointment?", a: "Yes! We reserve same-day slots for urgent cases and new patient consultations. Book online or call us directly for immediate availability." },
  { q: "What insurance do you accept?", a: "We accept most major dental insurance plans and also offer in-house financing options. Our team will help you maximize your benefits." },
  { q: "How long does a veneer procedure take?", a: "Porcelain veneers typically require two visits spread over 2–3 weeks. During the first visit, we prepare your teeth and take impressions. The second visit is for bonding your custom veneers." },
  { q: "What's the recovery time for dental implants?", a: "Most patients return to normal activities within 1–2 days after implant placement. Full integration with the jawbone takes 3–6 months, during which you'll have a temporary restoration." },
];

const FAQSection = () => (
  <section id="faq" className="py-24 md:py-32 bg-gradient-section">
    <div className="container mx-auto px-4">
      <ScrollReveal>
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-widest">FAQ</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-3 leading-[1.15]">
            Common Questions
          </h2>
          <p className="text-muted-foreground mt-4 text-lg">
            Everything you need to know before your visit.
          </p>
        </div>
      </ScrollReveal>

      <ScrollReveal delay={0.1}>
        <div className="max-w-2xl mx-auto">
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="glass-card rounded-xl px-6 border-none"
              >
                <AccordionTrigger className="text-left text-base font-medium text-foreground hover:no-underline py-5">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground pb-5 leading-relaxed">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </ScrollReveal>
    </div>
  </section>
);

export default FAQSection;
