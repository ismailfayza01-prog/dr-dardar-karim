import { motion } from "framer-motion";
import { Shield, Award, CreditCard, Heart } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const badges = [
  { icon: Shield, label: "Board Certified Dentists" },
  { icon: Award, label: "ADA Accredited Clinic" },
  { icon: CreditCard, label: "Flexible Payment Plans" },
  { icon: Heart, label: "Trusted by 500+ Families" },
];

const TrustStrip = () => (
  <section className="py-8 border-y border-border/50 bg-card/50">
    <div className="container mx-auto px-4">
      <ScrollReveal>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16">
          {badges.map((b, i) => (
            <motion.div
              key={b.label}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-center gap-3 text-muted-foreground"
            >
              <b.icon className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium whitespace-nowrap">{b.label}</span>
            </motion.div>
          ))}
        </div>
      </ScrollReveal>
    </div>
  </section>
);

export default TrustStrip;
