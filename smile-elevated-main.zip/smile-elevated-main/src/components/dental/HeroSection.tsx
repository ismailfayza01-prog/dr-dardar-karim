import { motion } from "framer-motion";
import { ArrowRight, MessageCircle, Star, Users, Zap, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedCounter from "./AnimatedCounter";
import heroImg from "@/assets/hero-clinic.jpg";

const statCards = [
  { icon: Users, label: "Happy Patients", value: 500, suffix: "+" },
  { icon: Star, label: "Patient Rating", value: 4.9, suffix: "/5", decimals: 1 },
  { icon: Zap, label: "Advanced Equipment", value: 0, suffix: "", text: "Latest Tech" },
  { icon: Clock, label: "Same-Day Consult", value: 0, suffix: "", text: "Available" },
];

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-gradient-hero overflow-hidden pt-20">
      {/* Subtle animated background shapes */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          animate={{ y: [0, -30, 0], x: [0, 15, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-20 -right-20 w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl"
        />
        <motion.div
          animate={{ y: [0, 20, 0], x: [0, -10, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-0 -left-20 w-[400px] h-[400px] rounded-full bg-accent/10 blur-3xl"
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Text side */}
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, y: 20, filter: "blur(4px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            >
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <Star className="w-3.5 h-3.5 fill-current" />
                Rated 4.9 by 500+ patients
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 24, filter: "blur(4px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight text-gradient-navy mb-6"
            >
              Your Smile Deserves{" "}
              <span className="block">World-Class Care</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 24, filter: "blur(4px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-md"
            >
              Experience premium dental care where advanced technology meets personalized comfort. 
              From cosmetic transformations to complete family dentistry — your confidence starts here.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 24, filter: "blur(4px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.7, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-wrap gap-3"
            >
              <Button variant="hero" size="xl" className="gap-2" asChild>
                <a href="#booking">
                  Book Appointment
                  <ArrowRight className="w-4 h-4" />
                </a>
              </Button>
              <Button variant="heroOutline" size="xl" className="gap-2" asChild>
                <a href="https://wa.me/15552345678" target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp Us
                </a>
              </Button>
            </motion.div>
          </div>

          {/* Image side */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, filter: "blur(8px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl glow-blue">
              <img
                src={heroImg}
                alt="Modern dental clinic interior with state-of-the-art equipment"
                className="w-full h-auto object-cover aspect-[4/3]"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/20 to-transparent" />
            </div>

            {/* Floating stat cards */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-4 sm:left-4 glass-card rounded-2xl px-5 py-4 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-xl font-bold text-foreground">
                  <AnimatedCounter target={500} suffix="+" />
                </div>
                <div className="text-xs text-muted-foreground">Happy Patients</div>
              </div>
            </motion.div>

            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute -top-4 -right-4 sm:right-4 glass-card rounded-2xl px-5 py-4 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-gold/20 flex items-center justify-center">
                <Star className="w-5 h-5 text-gold fill-gold" />
              </div>
              <div>
                <div className="text-xl font-bold text-foreground">
                  <AnimatedCounter target={4.9} suffix="/5" decimals={1} />
                </div>
                <div className="text-xs text-muted-foreground">Patient Rating</div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
