import { motion } from "framer-motion";
import { Sparkles, Wrench, Smile, AlignLeft, Stethoscope, AlertTriangle } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const services = [
  { icon: Sparkles, title: "Teeth Whitening", desc: "Professional-grade whitening for a brilliantly bright, natural-looking smile in a single visit." },
  { icon: Wrench, title: "Dental Implants", desc: "Permanent, natural-feeling tooth replacements using precision-guided titanium implant technology." },
  { icon: Smile, title: "Veneers & Hollywood Smile", desc: "Custom porcelain veneers designed to create your dream smile with flawless, lasting results." },
  { icon: AlignLeft, title: "Orthodontics & Aligners", desc: "Invisible aligners and modern braces for comfortable, discreet teeth straightening at any age." },
  { icon: Stethoscope, title: "General Dentistry", desc: "Comprehensive exams, cleanings, and preventive care to keep your oral health in peak condition." },
  { icon: AlertTriangle, title: "Emergency Dental Care", desc: "Same-day emergency appointments for pain relief, trauma, and urgent dental concerns." },
];

const ServicesSection = () => (
  <section id="services" className="py-24 md:py-32 bg-gradient-section">
    <div className="container mx-auto px-4">
      <ScrollReveal>
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-widest">Our Services</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-3 leading-[1.15]">
            Comprehensive Care, Exceptional Results
          </h2>
          <p className="text-muted-foreground mt-4 text-lg">
            From routine checkups to complete smile transformations, we offer a full range of dental services under one roof.
          </p>
        </div>
      </ScrollReveal>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s, i) => (
          <ScrollReveal key={s.title} delay={i * 0.08}>
            <motion.div
              whileHover={{ y: -4, boxShadow: "0 12px 40px hsl(220 50% 11% / 0.1)" }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="glass-card rounded-2xl p-8 h-full group cursor-pointer"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors duration-300">
                <s.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground font-display mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </motion.div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;
