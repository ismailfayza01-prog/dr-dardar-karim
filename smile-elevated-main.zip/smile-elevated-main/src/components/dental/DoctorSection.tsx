import { motion } from "framer-motion";
import { Award, GraduationCap, Clock } from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import doctorImg from "@/assets/doctor-portrait.jpg";

const credentials = [
  { icon: GraduationCap, label: "Columbia University School of Dental Medicine" },
  { icon: Award, label: "Fellow, American Academy of Cosmetic Dentistry" },
  { icon: Clock, label: "15+ Years of Clinical Experience" },
];

const DoctorSection = () => (
  <section id="team" className="py-24 md:py-32">
    <div className="container mx-auto px-4">
      <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        <ScrollReveal direction="left">
          <div className="relative max-w-md mx-auto lg:mx-0">
            <div className="rounded-3xl overflow-hidden shadow-xl">
              <img src={doctorImg} alt="Dr. Amara Chen, Lead Dentist" className="w-full h-auto object-cover aspect-[3/4]" />
            </div>
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -right-4 glass-card rounded-2xl px-6 py-4"
            >
              <div className="text-2xl font-bold text-foreground font-display">15+</div>
              <div className="text-xs text-muted-foreground">Years Experience</div>
            </motion.div>
          </div>
        </ScrollReveal>

        <ScrollReveal direction="right" delay={0.1}>
          <span className="text-sm font-medium text-primary uppercase tracking-widest">Meet Your Dentist</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3 leading-[1.15] font-display">
            Dr. Amara Chen
          </h2>
          <p className="text-sm text-primary font-medium mt-1">DDS, FAACD — Lead Cosmetic Dentist</p>
          <p className="text-muted-foreground mt-5 leading-relaxed">
            Dr. Chen has dedicated her career to helping patients achieve their most confident smiles. 
            Combining advanced cosmetic techniques with a gentle, patient-first approach, she brings 
            artistry and precision to every procedure. Her philosophy: exceptional results should never 
            come at the cost of your comfort.
          </p>

          <div className="mt-8 space-y-4">
            {credentials.map((c) => (
              <div key={c.label} className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <c.icon className="w-4 h-4 text-primary" />
                </div>
                <span className="text-sm text-foreground font-medium">{c.label}</span>
              </div>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </div>
  </section>
);

export default DoctorSection;
