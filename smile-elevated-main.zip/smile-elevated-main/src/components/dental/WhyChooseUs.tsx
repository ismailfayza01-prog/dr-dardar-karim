import { motion } from "framer-motion";
import { Cpu, UserCheck, FileText, HeartPulse, DollarSign, CalendarCheck } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const reasons = [
  { icon: Cpu, title: "Advanced Technology", desc: "3D imaging, digital scanning, and laser dentistry for precision care." },
  { icon: UserCheck, title: "Experienced Dentists", desc: "Board-certified specialists with 15+ years of clinical expertise." },
  { icon: FileText, title: "Personalized Plans", desc: "Every treatment plan is tailored to your unique needs and goals." },
  { icon: HeartPulse, title: "Pain-Free Experience", desc: "Gentle techniques and modern sedation options for complete comfort." },
  { icon: DollarSign, title: "Transparent Pricing", desc: "No hidden fees. Clear cost breakdowns before any procedure starts." },
  { icon: CalendarCheck, title: "Fast Booking", desc: "Book online in seconds. Same-day and next-day appointments available." },
];

const WhyChooseUs = () => (
  <section id="why-us" className="py-24 md:py-32 bg-gradient-section">
    <div className="container mx-auto px-4">
      <ScrollReveal>
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-widest">Why Lumière</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-3 leading-[1.15]">
            Designed Around Your Comfort
          </h2>
          <p className="text-muted-foreground mt-4 text-lg">
            We've rethought every part of the dental experience to make it feel more like a luxury wellness visit.
          </p>
        </div>
      </ScrollReveal>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {reasons.map((r, i) => (
          <ScrollReveal key={r.title} delay={i * 0.07}>
            <motion.div
              whileHover={{ y: -3 }}
              transition={{ duration: 0.2 }}
              className="glass-card rounded-2xl p-7 h-full"
            >
              <div className="w-11 h-11 rounded-xl bg-accent/40 flex items-center justify-center mb-4">
                <r.icon className="w-5 h-5 text-mint-deep" />
              </div>
              <h3 className="text-base font-semibold text-foreground font-display mb-1.5">{r.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{r.desc}</p>
            </motion.div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default WhyChooseUs;
