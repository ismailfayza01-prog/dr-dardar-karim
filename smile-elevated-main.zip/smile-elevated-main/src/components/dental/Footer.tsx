import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter } from "lucide-react";

const Footer = () => (
  <footer className="bg-navy text-primary-foreground/80">
    <div className="container mx-auto px-4 py-16">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-primary-foreground/10 flex items-center justify-center">
              <span className="text-sm font-bold text-primary-foreground font-display">L</span>
            </div>
            <span className="text-lg font-display font-bold text-primary-foreground">Lumière Dental</span>
          </div>
          <p className="text-sm leading-relaxed text-primary-foreground/60">
            Premium dental care where advanced technology meets personalized comfort.
          </p>
          <div className="flex gap-3 mt-5">
            {[Facebook, Instagram, Twitter].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="w-9 h-9 rounded-lg bg-primary-foreground/10 flex items-center justify-center hover:bg-primary-foreground/20 transition-colors"
              >
                <Icon className="w-4 h-4" />
              </a>
            ))}
          </div>
        </div>

        {/* Quick links */}
        <div>
          <h4 className="text-sm font-semibold text-primary-foreground uppercase tracking-wider mb-4">Quick Links</h4>
          <nav className="space-y-2.5">
            {["Services", "Results", "Our Team", "Testimonials", "FAQ"].map((l) => (
              <a key={l} href={`#${l.toLowerCase().replace(/\s/g, "-")}`} className="block text-sm text-primary-foreground/60 hover:text-primary-foreground transition-colors">
                {l}
              </a>
            ))}
          </nav>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-sm font-semibold text-primary-foreground uppercase tracking-wider mb-4">Contact</h4>
          <div className="space-y-3">
            {[
              { icon: MapPin, text: "123 Smile Avenue, Suite 200\nNew York, NY 10001" },
              { icon: Phone, text: "(555) 234-5678" },
              { icon: Mail, text: "hello@lumiere-dental.com" },
            ].map((c, i) => (
              <div key={i} className="flex items-start gap-3">
                <c.icon className="w-4 h-4 mt-0.5 flex-shrink-0 text-primary-foreground/40" />
                <span className="text-sm text-primary-foreground/60 whitespace-pre-line">{c.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Hours */}
        <div>
          <h4 className="text-sm font-semibold text-primary-foreground uppercase tracking-wider mb-4">Opening Hours</h4>
          <div className="space-y-2.5">
            {[
              { day: "Monday – Friday", hours: "8:00 AM – 7:00 PM" },
              { day: "Saturday", hours: "9:00 AM – 5:00 PM" },
              { day: "Sunday", hours: "Closed" },
            ].map((h) => (
              <div key={h.day} className="flex items-start gap-3">
                <Clock className="w-4 h-4 mt-0.5 flex-shrink-0 text-primary-foreground/40" />
                <div>
                  <div className="text-sm text-primary-foreground/80">{h.day}</div>
                  <div className="text-xs text-primary-foreground/50">{h.hours}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
    <div className="border-t border-primary-foreground/10 py-6">
      <div className="container mx-auto px-4 text-center text-xs text-primary-foreground/40">
        © {new Date().getFullYear()} Lumière Dental. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
