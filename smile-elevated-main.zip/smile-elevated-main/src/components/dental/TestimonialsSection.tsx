import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const testimonials = [
  {
    name: "Rachel M.",
    treatment: "Veneers",
    stars: 5,
    text: "I was terrified of dental work, but Dr. Chen and her team made me feel completely at ease. My new smile has genuinely changed how I carry myself — I can't stop smiling.",
  },
  {
    name: "David T.",
    treatment: "Dental Implants",
    stars: 5,
    text: "After years of hiding my teeth, I finally took the step. The implant process was smoother than I expected, and the result looks and feels completely natural. Worth every penny.",
  },
  {
    name: "Sophia L.",
    treatment: "Teeth Whitening",
    stars: 5,
    text: "One session and my teeth were several shades brighter. The clinic is gorgeous, the staff is so warm, and the results speak for themselves. I recommend Lumière to everyone.",
  },
  {
    name: "Marcus J.",
    treatment: "Orthodontics",
    stars: 5,
    text: "The clear aligners were practically invisible. In 8 months, my teeth were perfectly straight. The team tracked my progress closely and I never felt rushed or ignored.",
  },
];

const TestimonialsSection = () => {
  const [current, setCurrent] = useState(0);
  const next = () => setCurrent((c) => (c + 1) % testimonials.length);
  const prev = () => setCurrent((c) => (c - 1 + testimonials.length) % testimonials.length);

  return (
    <section id="testimonials" className="py-24 md:py-32">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-sm font-medium text-primary uppercase tracking-widest">Testimonials</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-3 leading-[1.15]">
              What Our Patients Say
            </h2>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <div className="max-w-2xl mx-auto relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, y: 16, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -16, filter: "blur(4px)" }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="glass-card rounded-3xl p-8 md:p-10 text-center"
              >
                <Quote className="w-8 h-8 text-primary/20 mx-auto mb-4" />
                <div className="flex items-center justify-center gap-1 mb-4">
                  {Array.from({ length: testimonials[current].stars }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-gold fill-gold" />
                  ))}
                </div>
                <p className="text-foreground leading-relaxed text-lg mb-6">
                  "{testimonials[current].text}"
                </p>
                <div className="font-semibold text-foreground">{testimonials[current].name}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{testimonials[current].treatment}</div>
              </motion.div>
            </AnimatePresence>

            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={prev}
                className="w-10 h-10 rounded-full border border-border flex items-center justify-center hover:bg-muted transition-colors active:scale-95"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="flex gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrent(i)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      i === current ? "bg-primary w-6" : "bg-border"
                    }`}
                    aria-label={`Go to testimonial ${i + 1}`}
                  />
                ))}
              </div>
              <button
                onClick={next}
                className="w-10 h-10 rounded-full border border-border flex items-center justify-center hover:bg-muted transition-colors active:scale-95"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default TestimonialsSection;
