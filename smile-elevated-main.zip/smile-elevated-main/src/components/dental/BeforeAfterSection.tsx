import { useState, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import smileBefore from "@/assets/smile-before.jpg";
import smileAfter from "@/assets/smile-after.jpg";

const BeforeAfterSection = () => {
  const [position, setPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setPosition((x / rect.width) * 100);
  }, []);

  const onPointerDown = () => { dragging.current = true; };
  const onPointerUp = () => { dragging.current = false; };
  const onPointerMove = (e: React.PointerEvent) => {
    if (dragging.current) handleMove(e.clientX);
  };

  return (
    <section id="results" className="py-24 md:py-32">
      <div className="container mx-auto px-4">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-sm font-medium text-primary uppercase tracking-widest">Real Results</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-3 leading-[1.15]">
              See the Transformation
            </h2>
            <p className="text-muted-foreground mt-4 text-lg">
              Drag the slider to reveal stunning before &amp; after results from real patient treatments.
            </p>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={0.15}>
          <div className="max-w-2xl mx-auto">
            <div
              ref={containerRef}
              className="relative rounded-2xl overflow-hidden shadow-xl cursor-col-resize select-none aspect-[3/2]"
              onPointerDown={onPointerDown}
              onPointerUp={onPointerUp}
              onPointerLeave={onPointerUp}
              onPointerMove={onPointerMove}
              onClick={(e) => handleMove(e.clientX)}
            >
              {/* Before (full width background) */}
              <img src={smileBefore} alt="Before dental treatment" className="absolute inset-0 w-full h-full object-cover" />

              {/* After (clipped) */}
              <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}>
                <img src={smileAfter} alt="After dental treatment" className="absolute inset-0 w-full h-full object-cover" />
              </div>

              {/* Handle */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-card shadow-lg z-10"
                style={{ left: `${position}%`, transform: "translateX(-50%)" }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-card shadow-lg flex items-center justify-center">
                  <ChevronLeft className="w-3.5 h-3.5 text-muted-foreground -mr-1" />
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground -ml-1" />
                </div>
              </div>

              {/* Labels */}
              <div className="absolute bottom-4 left-4 px-3 py-1.5 rounded-full bg-foreground/70 text-primary-foreground text-xs font-medium backdrop-blur-sm">
                Before
              </div>
              <div className="absolute bottom-4 right-4 px-3 py-1.5 rounded-full bg-primary/80 text-primary-foreground text-xs font-medium backdrop-blur-sm">
                After
              </div>
            </div>
            <p className="text-center text-xs text-muted-foreground mt-4">
              *Results shown are from actual patient cases. Individual results may vary.
            </p>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default BeforeAfterSection;
