import { motion } from "framer-motion";
import { CalendarPlus, Search, ClipboardList, Smile } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const steps = [
  { icon: CalendarPlus, step: "01", title: "Book Consultation", desc: "Schedule online or via WhatsApp in seconds." },
  { icon: Search, step: "02", title: "Get Diagnosis", desc: "Comprehensive exam with digital imaging and analysis." },
  { icon: ClipboardList, step: "03", title: "Treatment Plan", desc: "Receive a clear, personalized plan with transparent pricing." },
  { icon: Smile, step: "04", title: "Leave Smiling", desc: "Complete your treatment and enjoy your new confidence." },
];

const PatientJourney = () => (
  <section className="py-24 md:py-32 bg-gradient-section">
    <div className="container mx-auto px-4">
      <ScrollReveal>
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-medium text-primary uppercase tracking-widest">How It Works</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-3 leading-[1.15]">
            Your Journey to a Better Smile
          </h2>
        </div>
      </ScrollReveal>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((s, i) => (
          <ScrollReveal key={s.step} delay={i * 0.1}>
            <div className="relative text-center p-6">
              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.2 }}
                className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5"
              >
                <s.icon className="w-7 h-7 text-primary" />
              </motion.div>
              <span className="text-xs font-bold text-primary/60 uppercase tracking-widest">{s.step}</span>
              <h3 className="text-lg font-semibold text-foreground font-display mt-1 mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground">{s.desc}</p>

              {/* Connector line (hidden on last) */}
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-[calc(50%+40px)] w-[calc(100%-80px)] h-px bg-border" />
              )}
            </div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default PatientJourney;
