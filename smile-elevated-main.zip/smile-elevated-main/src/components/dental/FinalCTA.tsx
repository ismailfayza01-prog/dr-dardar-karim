import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, MessageCircle, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import ScrollReveal from "./ScrollReveal";

const FinalCTA = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="booking" className="py-24 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-cta" />
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-20 right-20 w-64 h-64 rounded-full bg-primary-foreground/5 blur-3xl"
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-primary-foreground leading-[1.15]">
              Ready for the Smile You Deserve?
            </h2>
            <p className="text-primary-foreground/70 mt-5 text-lg leading-relaxed max-w-md">
              Take the first step today. Book a consultation and discover how we can transform your smile 
              with comfort, precision, and care.
            </p>
            <div className="mt-8">
              <Button
                size="xl"
                className="bg-primary-foreground text-foreground hover:bg-primary-foreground/90 gap-2 shadow-lg"
                asChild
              >
                <a href="https://wa.me/15552345678" target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-4 h-4" />
                  Chat on WhatsApp
                </a>
              </Button>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.15}>
            {!submitted ? (
              <form
                onSubmit={handleSubmit}
                className="bg-card rounded-3xl p-8 shadow-2xl space-y-4"
              >
                <h3 className="text-xl font-semibold text-foreground font-display mb-2">
                  Request an Appointment
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Full Name"
                    required
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    required
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
                  />
                </div>
                <input
                  type="email"
                  placeholder="Email Address"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
                />
                <select
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
                  defaultValue=""
                >
                  <option value="" disabled>Select Service</option>
                  <option>Teeth Whitening</option>
                  <option>Dental Implants</option>
                  <option>Veneers / Hollywood Smile</option>
                  <option>Orthodontics / Aligners</option>
                  <option>General Dentistry</option>
                  <option>Emergency Care</option>
                </select>
                <textarea
                  placeholder="Tell us about your concerns (optional)"
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-shadow resize-none"
                />
                <Button variant="hero" size="lg" type="submit" className="w-full gap-2">
                  Book Now
                  <ArrowRight className="w-4 h-4" />
                </Button>
                <p className="text-xs text-muted-foreground text-center">
                  We'll confirm your appointment within 2 hours.
                </p>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-card rounded-3xl p-12 shadow-2xl text-center"
              >
                <CheckCircle2 className="w-14 h-14 text-mint-deep mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground font-display mb-2">
                  Thank You!
                </h3>
                <p className="text-muted-foreground">
                  We've received your request and will reach out within 2 hours to confirm your appointment.
                </p>
              </motion.div>
            )}
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;
