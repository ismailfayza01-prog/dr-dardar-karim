import Navbar from "@/components/dental/Navbar";
import HeroSection from "@/components/dental/HeroSection";
import TrustStrip from "@/components/dental/TrustStrip";
import ServicesSection from "@/components/dental/ServicesSection";
import BeforeAfterSection from "@/components/dental/BeforeAfterSection";
import WhyChooseUs from "@/components/dental/WhyChooseUs";
import DoctorSection from "@/components/dental/DoctorSection";
import PatientJourney from "@/components/dental/PatientJourney";
import TestimonialsSection from "@/components/dental/TestimonialsSection";
import FAQSection from "@/components/dental/FAQSection";
import FinalCTA from "@/components/dental/FinalCTA";
import Footer from "@/components/dental/Footer";
import WhatsAppButton from "@/components/dental/WhatsAppButton";
import ScrollProgress from "@/components/dental/ScrollProgress";

const Index = () => (
  <>
    <ScrollProgress />
    <Navbar />
    <main>
      <HeroSection />
      <TrustStrip />
      <ServicesSection />
      <BeforeAfterSection />
      <WhyChooseUs />
      <DoctorSection />
      <PatientJourney />
      <TestimonialsSection />
      <FAQSection />
      <FinalCTA />
    </main>
    <Footer />
    <WhatsAppButton />
  </>
);

export default Index;
